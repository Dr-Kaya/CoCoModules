import { z } from "zod";

export const ballTypeSchema = z.enum(["basketball", "soccer"]);
export type BallType = z.infer<typeof ballTypeSchema>;

export const gamePhaseSchema = z.enum([
  "welcome",
  "learn",
  "train1",
  "test1",
  "train2",
  "test2",
  "deploy",
  "assessment"
]);
export type GamePhase = z.infer<typeof gamePhaseSchema>;

export const ballSchema = z.object({
  id: z.string(),
  type: ballTypeSchema,
  variant: z.number()
});
export type Ball = z.infer<typeof ballSchema>;

export const trainingResultSchema = z.object({
  ballId: z.string(),
  ballType: ballTypeSchema,
  userClassification: ballTypeSchema,
  correct: z.boolean()
});
export type TrainingResult = z.infer<typeof trainingResultSchema>;

export const testResultSchema = z.object({
  ballId: z.string(),
  ballType: ballTypeSchema,
  botClassification: ballTypeSchema,
  correct: z.boolean()
});
export type TestResult = z.infer<typeof testResultSchema>;

export const assessmentAnswerSchema = z.object({
  questionId: z.string(),
  answer: z.union([z.string(), z.array(z.string()), z.number()]),
  correct: z.boolean().optional()
});
export type AssessmentAnswer = z.infer<typeof assessmentAnswerSchema>;

export const gameStateSchema = z.object({
  phase: gamePhaseSchema,
  trainingExamples: z.number(),
  phase1Accuracy: z.number(),
  phase2Accuracy: z.number(),
  currentBallIndex: z.number(),
  trainingResults: z.array(trainingResultSchema),
  testResults: z.array(testResultSchema),
  assessmentAnswers: z.array(assessmentAnswerSchema),
  predictions: z.record(z.string(), z.string()),
  studentName: z.string()
});
export type GameState = z.infer<typeof gameStateSchema>;

export const certificateSchema = z.object({
  studentName: z.string(),
  date: z.string(),
  trainingExamples: z.number(),
  finalAccuracy: z.number()
});
export type Certificate = z.infer<typeof certificateSchema>;

export const insertCertificateSchema = certificateSchema;
export type InsertCertificate = z.infer<typeof insertCertificateSchema>;

export const users = null;
export type User = { id: string; username: string; password: string };
export type InsertUser = { username: string; password: string };

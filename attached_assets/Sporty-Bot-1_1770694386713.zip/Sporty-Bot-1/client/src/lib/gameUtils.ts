import type { Ball, BallType, GameState } from "@shared/schema";

export function generateBalls(count: number): Ball[] {
  const balls: Ball[] = [];
  for (let i = 0; i < count; i++) {
    const type: BallType = i % 2 === 0 ? "basketball" : "soccer";
    balls.push({
      id: `ball-${Date.now()}-${i}`,
      type,
      variant: Math.floor(Math.random() * 8) + 1
    });
  }
  return shuffleArray(balls);
}

export function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export function calculateAccuracy(correct: number, total: number): number {
  if (total === 0) return 0;
  return Math.round((correct / total) * 100);
}

export function simulateBotClassification(
  ball: Ball,
  trainingExamples: number
): BallType {
  const baseConfidence = trainingExamples <= 8 ? 0.65 : 0.90;
  const randomFactor = Math.random();
  
  if (randomFactor < baseConfidence) {
    return ball.type;
  }
  return ball.type === "basketball" ? "soccer" : "basketball";
}

export function calculateConfidence(correct: number, total: number): number {
  if (total === 0) return 0;
  return Math.round((correct / total) * 100);
}

export function getInitialGameState(): GameState {
  return {
    phase: "welcome",
    trainingExamples: 0,
    phase1Accuracy: 0,
    phase2Accuracy: 0,
    currentBallIndex: 0,
    trainingResults: [],
    testResults: [],
    assessmentAnswers: [],
    predictions: {},
    studentName: ""
  };
}

export function getEncouragementMessage(index: number): string {
  const messages = [
    "Great job!",
    "I'm learning!",
    "Keep going!",
    "You're amazing!",
    "That helps a lot!",
    "I'm getting smarter!",
    "Wonderful!",
    "Perfect!"
  ];
  return messages[index % messages.length];
}

export function getBotMood(accuracy: number): "happy" | "neutral" | "sad" {
  if (accuracy >= 80) return "happy";
  if (accuracy >= 50) return "neutral";
  return "sad";
}

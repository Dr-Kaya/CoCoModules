import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ProgressIndicator } from "@/components/ProgressIndicator";
import { WelcomeScreen } from "@/components/screens/WelcomeScreen";
import { LearnScreen } from "@/components/screens/LearnScreen";
import { TrainScreen } from "@/components/screens/TrainScreen";
import { TestScreen } from "@/components/screens/TestScreen";
import { PredictionScreen } from "@/components/screens/PredictionScreen";
import { DeployScreen } from "@/components/screens/DeployScreen";
import { AssessmentScreen } from "@/components/screens/AssessmentScreen";
import { getInitialGameState } from "@/lib/gameUtils";
import type { GamePhase, GameState, TestResult, AssessmentAnswer } from "@shared/schema";

export default function Home() {
  const [gameState, setGameState] = useState<GameState>(getInitialGameState);
  const [showPrediction, setShowPrediction] = useState(false);

  const updatePhase = useCallback((phase: GamePhase) => {
    setGameState(prev => ({ ...prev, phase }));
  }, []);

  const addAssessmentAnswer = useCallback((questionId: string, answer: string) => {
    const newAnswer: AssessmentAnswer = {
      questionId,
      answer,
      correct: undefined
    };
    setGameState(prev => ({
      ...prev,
      assessmentAnswers: [...prev.assessmentAnswers, newAnswer]
    }));
  }, []);

  const handleWelcomeStart = useCallback(() => {
    updatePhase("learn");
  }, [updatePhase]);

  const handleLearnComplete = useCallback(() => {
    updatePhase("train1");
  }, [updatePhase]);

  const handleTrain1Complete = useCallback((results: { correct: number; total: number }) => {
    setGameState(prev => ({
      ...prev,
      trainingExamples: results.total,
      phase: "test1"
    }));
  }, []);

  const handleTest1Complete = useCallback((results: { accuracy: number; testResults: TestResult[] }) => {
    setGameState(prev => ({
      ...prev,
      phase1Accuracy: results.accuracy,
      testResults: results.testResults,
      phase: "train2"
    }));
  }, []);

  const handleTrain2Complete = useCallback((results: { correct: number; total: number }) => {
    setShowPrediction(true);
    setGameState(prev => ({
      ...prev,
      trainingExamples: prev.trainingExamples + results.total
    }));
  }, []);

  const handlePrediction = useCallback((prediction: string) => {
    setShowPrediction(false);
    setGameState(prev => ({
      ...prev,
      predictions: { ...prev.predictions, phase2: prediction },
      phase: "test2"
    }));
  }, []);

  const handleTest2Complete = useCallback((results: { accuracy: number; testResults: TestResult[] }) => {
    setGameState(prev => ({
      ...prev,
      phase2Accuracy: results.accuracy,
      testResults: [...prev.testResults, ...results.testResults],
      phase: "deploy"
    }));
  }, []);

  const handleDeployContinue = useCallback(() => {
    updatePhase("assessment");
  }, [updatePhase]);

  const handleRestart = useCallback(() => {
    setGameState(getInitialGameState());
    setShowPrediction(false);
  }, []);

  const showProgress = gameState.phase !== "welcome";

  return (
    <div className="min-h-screen bg-background">
      {showProgress && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="sticky top-0 bg-background/95 backdrop-blur-sm border-b border-border z-40"
        >
          <ProgressIndicator currentPhase={gameState.phase} />
        </motion.div>
      )}

      <AnimatePresence mode="wait">
        {gameState.phase === "welcome" && (
          <motion.div
            key="welcome"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <WelcomeScreen onStart={handleWelcomeStart} />
          </motion.div>
        )}

        {gameState.phase === "learn" && (
          <motion.div
            key="learn"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
          >
            <LearnScreen 
              onComplete={handleLearnComplete}
              onAssessmentAnswer={addAssessmentAnswer}
            />
          </motion.div>
        )}

        {gameState.phase === "train1" && (
          <motion.div
            key="train1"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
          >
            <TrainScreen 
              phase={1}
              onComplete={handleTrain1Complete}
              onAssessmentAnswer={addAssessmentAnswer}
            />
          </motion.div>
        )}

        {gameState.phase === "test1" && (
          <motion.div
            key="test1"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
          >
            <TestScreen 
              phase={1}
              trainingExamples={gameState.trainingExamples}
              onComplete={handleTest1Complete}
              onAssessmentAnswer={addAssessmentAnswer}
            />
          </motion.div>
        )}

        {gameState.phase === "train2" && !showPrediction && (
          <motion.div
            key="train2"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
          >
            <TrainScreen 
              phase={2}
              onComplete={handleTrain2Complete}
              onAssessmentAnswer={addAssessmentAnswer}
              previousTotal={gameState.trainingExamples}
            />
          </motion.div>
        )}

        {gameState.phase === "train2" && showPrediction && (
          <motion.div
            key="prediction"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
          >
            <PredictionScreen 
              onPredict={handlePrediction}
              trainingExamples={gameState.trainingExamples}
            />
          </motion.div>
        )}

        {gameState.phase === "test2" && (
          <motion.div
            key="test2"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
          >
            <TestScreen 
              phase={2}
              trainingExamples={gameState.trainingExamples}
              onComplete={handleTest2Complete}
              onAssessmentAnswer={addAssessmentAnswer}
              previousAccuracy={gameState.phase1Accuracy}
              prediction={gameState.predictions.phase2}
            />
          </motion.div>
        )}

        {gameState.phase === "deploy" && (
          <motion.div
            key="deploy"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
          >
            <DeployScreen 
              trainingExamples={gameState.trainingExamples}
              phase1Accuracy={gameState.phase1Accuracy}
              phase2Accuracy={gameState.phase2Accuracy}
              onContinue={handleDeployContinue}
            />
          </motion.div>
        )}

        {gameState.phase === "assessment" && (
          <motion.div
            key="assessment"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0 }}
          >
            <AssessmentScreen 
              trainingExamples={gameState.trainingExamples}
              finalAccuracy={gameState.phase2Accuracy}
              onRestart={handleRestart}
              onAssessmentAnswer={addAssessmentAnswer}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

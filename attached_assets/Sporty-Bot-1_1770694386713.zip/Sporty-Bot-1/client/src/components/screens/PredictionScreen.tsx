import { motion } from "framer-motion";
import { QuickCheck } from "@/components/QuickCheck";
import { SportyBot } from "@/components/SportyBot";

interface PredictionScreenProps {
  onPredict: (prediction: string) => void;
  trainingExamples: number;
}

export function PredictionScreen({ onPredict, trainingExamples }: PredictionScreenProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-lg w-full"
      >
        <div className="text-center mb-8">
          <SportyBot mood="thinking" size="md" message={`I've now learned from ${trainingExamples} examples!`} />
        </div>

        <QuickCheck
          question="We've given Sporty Bot more examples. What do you predict will happen to its accuracy?"
          type="prediction"
          icon="💡"
          options={[
            { value: "up", label: "📈 It will get better (go up)" },
            { value: "down", label: "📉 It will get worse (go down)" },
            { value: "same", label: "➡️ It will stay the same" }
          ]}
          onAnswer={onPredict}
        />
      </motion.div>
    </div>
  );
}

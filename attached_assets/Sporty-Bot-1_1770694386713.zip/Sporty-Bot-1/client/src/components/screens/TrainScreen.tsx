import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence, PanInfo } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import { Card } from "@/components/ui/card";
import { SportyBot } from "@/components/SportyBot";
import { Basket } from "@/components/Basket";
import { QuickCheck } from "@/components/QuickCheck";
import { SelfRegulatedCheck } from "@/components/SelfRegulatedCheck";
import { CircularMLCycle } from "@/components/ProgressIndicator";
import { generateBalls, getEncouragementMessage } from "@/lib/gameUtils";
import { Lightbulb } from "lucide-react";
import type { Ball as BallType, BallType as BallTypeEnum } from "@shared/schema";

const mlTips = [
  { tip: "Diverse data helps AI learn better!", detail: "Include different angles, sizes, and lighting" },
  { tip: "More examples = smarter AI!", detail: "Just like you need practice to get good at something" },
  { tip: "Quality matters too!", detail: "Make sure each example is correctly labeled" },
  { tip: "AI learns patterns from data", detail: "It looks for what makes each type unique" },
  { tip: "Balanced data is important!", detail: "Try to have similar amounts of each type" },
  { tip: "Real-world data is messy", detail: "That's why we need lots of different examples" },
];

function DraggableBall({ type, variant }: { type: BallTypeEnum; variant: number }) {
  const ballVariations = [
    { rotation: 0, scale: 1.0, brightness: 1.0 },
    { rotation: 15, scale: 0.85, brightness: 0.95 },
    { rotation: -20, scale: 1.1, brightness: 1.05 },
    { rotation: 30, scale: 0.9, brightness: 0.9 },
    { rotation: -35, scale: 0.95, brightness: 1.0 },
    { rotation: 45, scale: 1.15, brightness: 1.1 },
    { rotation: -10, scale: 0.8, brightness: 0.85 },
    { rotation: 25, scale: 1.05, brightness: 0.98 },
  ];
  
  const variation = ballVariations[(variant - 1) % ballVariations.length];
  const { rotation, brightness } = variation;
  
  if (type === "basketball") {
    return (
      <div 
        className="w-32 h-32 select-none"
        style={{ 
          transform: `rotate(${rotation}deg)`,
          filter: `brightness(${brightness})`
        }}
      >
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-xl">
          <defs>
            <radialGradient id={`drag-basketball-grad-${variant}`} cx="30%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#FF8A5B" />
              <stop offset="100%" stopColor="#FF6B35" />
            </radialGradient>
          </defs>
          <circle cx="50" cy="50" r="48" fill={`url(#drag-basketball-grad-${variant})`} stroke="#CC5522" strokeWidth="2" />
          <path d="M 50 2 Q 50 50 50 98" stroke="#1a1a2e" strokeWidth="2.5" fill="none" />
          <path d="M 2 50 Q 50 50 98 50" stroke="#1a1a2e" strokeWidth="2.5" fill="none" />
          <path d="M 15 15 Q 50 35 85 15" stroke="#1a1a2e" strokeWidth="2.5" fill="none" />
          <path d="M 15 85 Q 50 65 85 85" stroke="#1a1a2e" strokeWidth="2.5" fill="none" />
        </svg>
      </div>
    );
  }
  
  return (
    <div 
      className="w-32 h-32 select-none"
      style={{ 
        transform: `rotate(${rotation}deg)`,
        filter: `brightness(${brightness})`
      }}
    >
      <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-xl">
        <defs>
          <radialGradient id={`drag-soccer-grad-${variant}`} cx="30%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="100%" stopColor="#E8E8E8" />
          </radialGradient>
        </defs>
        <circle cx="50" cy="50" r="48" fill={`url(#drag-soccer-grad-${variant})`} stroke="#333" strokeWidth="2" />
        <polygon points="50,20 65,35 60,55 40,55 35,35" fill="#1a1a2e" />
        <polygon points="80,45 85,60 75,75 60,70 60,55" fill="#1a1a2e" />
        <polygon points="20,45 15,60 25,75 40,70 40,55" fill="#1a1a2e" />
        <polygon points="35,80 50,90 65,80 60,70 40,70" fill="#1a1a2e" />
        <polygon points="35,20 50,10 50,20 35,35 25,25" fill="#1a1a2e" />
        <polygon points="65,20 50,10 50,20 65,35 75,25" fill="#1a1a2e" />
      </svg>
    </div>
  );
}

interface TrainScreenProps {
  phase: 1 | 2;
  onComplete: (results: { correct: number; total: number }) => void;
  onAssessmentAnswer: (questionId: string, answer: string) => void;
  previousTotal?: number;
}

type TrainStep = "training" | "midcheck" | "complete" | "selfcheck";

export function TrainScreen({ 
  phase, 
  onComplete, 
  onAssessmentAnswer,
  previousTotal = 0 
}: TrainScreenProps) {
  const ballCount = phase === 1 ? 8 : 12;
  const initialBasketball = phase === 1 ? 2 : 4;
  const initialSoccer = phase === 1 ? 2 : 4;
  
  const [balls] = useState<BallType[]>(() => generateBalls(ballCount));
  const [currentIndex, setCurrentIndex] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [basketballCount, setBasketballCount] = useState(initialBasketball);
  const [soccerCount, setSoccerCount] = useState(initialSoccer);
  const [step, setStep] = useState<TrainStep>("training");
  const [message, setMessage] = useState("");
  const [activeBasket, setActiveBasket] = useState<BallTypeEnum | null>(null);
  const [showMidCheck, setShowMidCheck] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [hoverBasket, setHoverBasket] = useState<BallTypeEnum | null>(null);
  const [currentTip] = useState(() => mlTips[Math.floor(Math.random() * mlTips.length)]);
  
  const basketballRef = useRef<HTMLDivElement>(null);
  const soccerRef = useRef<HTMLDivElement>(null);
  const ballRef = useRef<HTMLDivElement>(null);

  const currentBall = balls[currentIndex];
  const progress = ((currentIndex + (isProcessing ? 1 : 0)) / ballCount) * 100;
  const totalSorted = previousTotal + currentIndex + (isProcessing ? 1 : 0);
  const displayIndex = currentIndex + (isProcessing ? 1 : 0);
  const totalDataPoints = basketballCount + soccerCount;

  useEffect(() => {
    if (phase === 1 && currentIndex === 4 && !showMidCheck && step === "training") {
      setShowMidCheck(true);
      setStep("midcheck");
    }
  }, [currentIndex, phase, showMidCheck, step]);

  const checkBasketCollision = useCallback((point: { x: number; y: number }): BallTypeEnum | null => {
    const basketballRect = basketballRef.current?.getBoundingClientRect();
    const soccerRect = soccerRef.current?.getBoundingClientRect();
    
    if (basketballRect && 
        point.x >= basketballRect.left && 
        point.x <= basketballRect.right && 
        point.y >= basketballRect.top && 
        point.y <= basketballRect.bottom) {
      return "basketball";
    }
    
    if (soccerRect && 
        point.x >= soccerRect.left && 
        point.x <= soccerRect.right && 
        point.y >= soccerRect.top && 
        point.y <= soccerRect.bottom) {
      return "soccer";
    }
    
    return null;
  }, []);

  const handleDrag = useCallback((event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    const ballRect = ballRef.current?.getBoundingClientRect();
    if (!ballRect) return;
    
    const centerX = ballRect.left + ballRect.width / 2;
    const centerY = ballRect.top + ballRect.height / 2;
    
    const basket = checkBasketCollision({ x: centerX, y: centerY });
    setHoverBasket(basket);
  }, [checkBasketCollision]);

  const handleDragEnd = useCallback((event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (!currentBall || step !== "training" || isProcessing) return;
    
    const ballRect = ballRef.current?.getBoundingClientRect();
    if (!ballRect) return;
    
    const centerX = ballRect.left + ballRect.width / 2;
    const centerY = ballRect.top + ballRect.height / 2;
    
    const basket = checkBasketCollision({ x: centerX, y: centerY });
    setHoverBasket(null);
    setIsDragging(false);
    
    if (basket) {
      handleDrop(basket);
    }
  }, [currentBall, step, isProcessing, checkBasketCollision]);

  const handleDrop = (basket: BallTypeEnum) => {
    if (!currentBall || step !== "training" || isProcessing) return;
    
    setIsProcessing(true);
    setActiveBasket(basket);
    
    if (basket === "basketball") {
      setBasketballCount(prev => prev + 1);
    } else {
      setSoccerCount(prev => prev + 1);
    }
    
    const isCorrect = currentBall.type === basket;
    if (isCorrect) {
      setCorrectCount(prev => prev + 1);
    }
    
    setMessage(getEncouragementMessage(currentIndex));
    const nextIndex = currentIndex + 1;
    
    setTimeout(() => {
      setMessage("");
      setActiveBasket(null);
      setIsProcessing(false);
      
      if (nextIndex >= ballCount) {
        setStep("selfcheck");
      } else {
        setCurrentIndex(nextIndex);
      }
    }, 800);
  };

  const handleBasketClick = (basket: BallTypeEnum) => {
    handleDrop(basket);
  };

  if (step === "midcheck") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <QuickCheck
          question="What is Sporty Bot doing right now?"
          type="multiple"
          icon="⚡"
          options={[
            { value: "playing", label: "Playing a game", isCorrect: false },
            { value: "learning", label: "Learning from the examples you give it", isCorrect: true },
            { value: "napping", label: "Taking a nap", isCorrect: false }
          ]}
          onAnswer={(answer) => {
            onAssessmentAnswer(`midcheck-phase${phase}`, answer);
            setStep("training");
          }}
          feedback={{
            correct: "Exactly! Every ball you sort helps Sporty Bot learn patterns.",
            incorrect: "Remember, you're teaching! Every ball you sort helps Sporty Bot learn."
          }}
        />
      </div>
    );
  }

  if (step === "selfcheck") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <SelfRegulatedCheck
          type={phase === 1 ? "brain" : "strategy"}
          title={phase === 1 ? "How are you feeling?" : "Strategy Check!"}
          prompt={
            phase === 1 
              ? "Let's check in on your understanding!" 
              : "What strategy helped Sporty Bot improve?"
          }
          options={
            phase === 1
              ? [
                  { value: "confused", label: "A little confused", emoji: "😟" },
                  { value: "neutral", label: "I think I get it", emoji: "😐" },
                  { value: "understand", label: "I understand!", emoji: "😄" }
                ]
              : [
                  { value: "examples", label: "More training examples", emoji: "🎯" },
                  { value: "practice", label: "Practice and repetition", emoji: "🔄" },
                  { value: "both", label: "Both!", emoji: "✨" }
                ]
          }
          onComplete={(response) => {
            if (response.selection) {
              onAssessmentAnswer(`selfcheck-phase${phase}`, response.selection);
            }
            onComplete({ correct: correctCount, total: ballCount });
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col p-6">
      <div className="flex justify-center mb-4">
        <CircularMLCycle currentStep={phase === 1 ? "train" : "improve"} size="sm" />
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-4"
      >
        <h1 className="text-3xl md:text-4xl font-bold text-foreground" data-testid="text-train-title">
          {phase === 1 ? "Collect Training Data!" : "Improve with More Data!"}
        </h1>
        <p className="text-muted-foreground mt-2">
          {phase === 1 
            ? "Drag each ball to the correct basket to teach Sporty Bot" 
            : "More diverse examples will help Sporty Bot learn better!"
          }
        </p>
      </motion.div>

      <Card className="max-w-md mx-auto w-full p-3 mb-4 bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
        <div className="flex items-start gap-2">
          <Lightbulb className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-amber-800 dark:text-amber-300">{currentTip.tip}</p>
            <p className="text-xs text-amber-600 dark:text-amber-400">{currentTip.detail}</p>
          </div>
        </div>
      </Card>

      <div className="flex items-center justify-between mb-4 max-w-md mx-auto w-full">
        <span className="text-sm font-medium" data-testid="text-balls-sorted">
          Balls Sorted: {displayIndex}/{ballCount}
        </span>
        <span className="text-sm font-bold text-primary" data-testid="text-total-data">
          Dataset: {totalDataPoints} examples
        </span>
      </div>
      <Progress value={progress} className="max-w-md mx-auto w-full mb-6" />

      <div className="flex-1 flex flex-col items-center justify-between max-w-4xl mx-auto w-full">
        <div className="flex items-center gap-8 mb-8">
          <AnimatePresence mode="wait">
            {currentBall && step === "training" && !isProcessing && (
              <motion.div
                key={currentBall.id}
                initial={{ opacity: 0, scale: 0, y: -50 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0 }}
                transition={{ type: "spring", stiffness: 300 }}
                className="flex flex-col items-center"
              >
                <p className="text-lg font-medium mb-4 text-muted-foreground">
                  {isDragging ? "Drop it in the right basket!" : "Drag the ball to the correct basket!"}
                </p>
                <motion.div
                  ref={ballRef}
                  drag
                  dragConstraints={{ left: -300, right: 300, top: -100, bottom: 300 }}
                  dragElastic={0.1}
                  onDragStart={() => setIsDragging(true)}
                  onDrag={handleDrag}
                  onDragEnd={handleDragEnd}
                  whileDrag={{ scale: 1.1, zIndex: 100 }}
                  className="cursor-grab active:cursor-grabbing touch-none"
                  data-testid="draggable-ball"
                >
                  <DraggableBall 
                    type={currentBall.type} 
                    variant={currentBall.variant}
                  />
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="flex justify-center gap-8 md:gap-16 mb-8">
          <div 
            ref={basketballRef}
            onClick={() => handleBasketClick("basketball")}
            className="cursor-pointer transition-transform"
            data-testid="clickable-basket-basketball"
          >
            <Basket 
              type="basketball" 
              isActive={activeBasket === "basketball"} 
              isHovered={hoverBasket === "basketball"}
              ballCount={basketballCount}
            />
          </div>
          <div 
            ref={soccerRef}
            onClick={() => handleBasketClick("soccer")}
            className="cursor-pointer transition-transform"
            data-testid="clickable-basket-soccer"
          >
            <Basket 
              type="soccer" 
              isActive={activeBasket === "soccer"} 
              isHovered={hoverBasket === "soccer"}
              ballCount={soccerCount}
            />
          </div>
        </div>

        <div className="flex justify-center">
          <SportyBot 
            mood={message ? "happy" : isDragging ? "excited" : "neutral"} 
            size="md" 
            message={message || (isDragging ? "That's it! Drop it in!" : phase === 2 ? "I'm getting smarter!" : "Drag to teach me!")}
          />
        </div>
      </div>
    </div>
  );
}

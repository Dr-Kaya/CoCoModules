import { useState } from "react";
import { motion, AnimatePresence, Reorder } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { SportyBot } from "@/components/SportyBot";
import { Confetti } from "@/components/Confetti";
import { QuickCheck } from "@/components/QuickCheck";
import { Star, Download, RotateCcw, Award } from "lucide-react";

interface AssessmentScreenProps {
  trainingExamples: number;
  finalAccuracy: number;
  onRestart: () => void;
  onAssessmentAnswer: (questionId: string, answer: string) => void;
}

type AssessmentStep = "ordering" | "transfer" | "reflection" | "certificate";

const correctOrder = ["Collect data", "Train with examples", "Test the model", "Improve with more training", "Deploy (use it!)"];

export function AssessmentScreen({ 
  trainingExamples, 
  finalAccuracy, 
  onRestart,
  onAssessmentAnswer 
}: AssessmentScreenProps) {
  const [step, setStep] = useState<AssessmentStep>("ordering");
  const [orderItems, setOrderItems] = useState([
    "Test the model",
    "Train with examples",
    "Deploy (use it!)",
    "Collect data",
    "Improve with more training"
  ]);
  const [studentName, setStudentName] = useState("");
  const [starRating, setStarRating] = useState(0);
  const [rememberText, setRememberText] = useState("");
  const [questionText, setQuestionText] = useState("");
  const [showConfetti, setShowConfetti] = useState(false);

  const checkOrder = () => {
    const isCorrect = orderItems.every((item, i) => item === correctOrder[i]);
    onAssessmentAnswer("ml-ordering", isCorrect ? "correct" : "incorrect");
    setStep("transfer");
  };

  const handleReflectionComplete = () => {
    onAssessmentAnswer("star-rating", starRating.toString());
    if (rememberText) onAssessmentAnswer("remember-text", rememberText);
    if (questionText) onAssessmentAnswer("question-text", questionText);
    setShowConfetti(true);
    setStep("certificate");
  };

  const downloadCertificate = () => {
    const certificateText = `
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║                    🤖 AI TEACHER CERTIFICATE 🤖               ║
║                                                              ║
║   This certifies that                                        ║
║                                                              ║
║                     ${studentName || "Amazing Student"}                          
║                                                              ║
║   has successfully completed the Sporty Bot                  ║
║   Machine Learning Training Program!                         ║
║                                                              ║
║   📊 Training Examples: ${trainingExamples}                               
║   🎯 Final Accuracy: ${finalAccuracy}%                                   
║   📅 Date: ${new Date().toLocaleDateString()}                             
║                                                              ║
║   Key Achievement:                                           ║
║   Learned the ML Lifecycle: Collect → Train → Test →         ║
║   Improve → Deploy                                           ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
    `;
    
    const blob = new Blob([certificateText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ai-teacher-certificate.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  if (step === "ordering") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-lg"
        >
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold flex items-center justify-center gap-2">
              <span className="text-3xl">🏆</span> Final Challenge!
            </h1>
            <p className="text-muted-foreground mt-2">
              Put the ML lifecycle steps in the correct order by dragging them!
            </p>
          </div>

          <Card className="p-6">
            <Reorder.Group 
              axis="y" 
              values={orderItems} 
              onReorder={setOrderItems}
              className="space-y-2"
            >
              {orderItems.map((item, index) => (
                <Reorder.Item
                  key={item}
                  value={item}
                  className="bg-muted p-4 rounded-lg cursor-grab active:cursor-grabbing flex items-center gap-3 hover:bg-muted/80"
                  data-testid={`order-item-${index}`}
                >
                  <span className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                    {index + 1}
                  </span>
                  <span className="font-medium">{item}</span>
                </Reorder.Item>
              ))}
            </Reorder.Group>

            <Button 
              onClick={checkOrder} 
              className="w-full mt-6"
              data-testid="button-check-order"
            >
              Check My Answer
            </Button>
          </Card>
        </motion.div>
      </div>
    );
  }

  if (step === "transfer") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <QuickCheck
          question="Where else might AI learn from examples like this?"
          type="multiple"
          icon="🌍"
          options={[
            { value: "faces", label: "Recognizing faces in photos", isCorrect: false },
            { value: "videos", label: "Suggesting videos you might like", isCorrect: false },
            { value: "doctors", label: "Helping doctors look at X-rays", isCorrect: false },
            { value: "all", label: "All of the above!", isCorrect: true }
          ]}
          onAnswer={(answer) => {
            onAssessmentAnswer("transfer-knowledge", answer);
            setStep("reflection");
          }}
          feedback={{
            correct: "Yes! AI uses examples to learn many different things - from recognizing faces to helping doctors!",
            incorrect: "Actually, all of these use AI that learns from examples! It's used in many areas."
          }}
        />
      </div>
    );
  }

  if (step === "reflection") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-lg"
        >
          <Card className="p-6 bg-gradient-to-br from-yellow-500/10 to-orange-500/10">
            <div className="flex items-center gap-3 mb-6">
              <span className="text-4xl">⭐</span>
              <div>
                <h2 className="text-xl font-bold">Success Check</h2>
                <p className="text-sm text-muted-foreground">Let's reflect on what you learned!</p>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-card p-4 rounded-lg">
                <p className="font-medium mb-2">Look back at your learning goals:</p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <span className="text-green-500">✅</span>
                    Did you learn how machines learn from examples?
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-green-500">✅</span>
                    Did you successfully teach Sporty Bot?
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-green-500">✅</span>
                    Did you see how practice makes AI better?
                  </li>
                </ul>
              </div>

              <div>
                <p className="font-medium mb-3">Rate your learning:</p>
                <div className="flex justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setStarRating(star)}
                      className="p-1 transition-transform hover:scale-110"
                      data-testid={`star-${star}`}
                    >
                      <Star 
                        className={`w-10 h-10 ${
                          star <= starRating 
                            ? 'fill-yellow-400 text-yellow-400' 
                            : 'text-muted-foreground'
                        }`} 
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-medium mb-2">
                  💭 One thing I want to remember:
                </label>
                <Textarea 
                  value={rememberText}
                  onChange={(e) => setRememberText(e.target.value)}
                  placeholder="Type here..."
                  className="min-h-[80px]"
                  data-testid="input-remember"
                />
              </div>

              <div>
                <label className="block font-medium mb-2">
                  💭 One question I still have:
                </label>
                <Textarea 
                  value={questionText}
                  onChange={(e) => setQuestionText(e.target.value)}
                  placeholder="Type here... (optional)"
                  className="min-h-[80px]"
                  data-testid="input-question"
                />
              </div>

              <div>
                <label className="block font-medium mb-2">
                  Your name for the certificate:
                </label>
                <Input 
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="Enter your name"
                  data-testid="input-name"
                />
              </div>

              <Button 
                onClick={handleReflectionComplete}
                className="w-full"
                disabled={starRating === 0}
                data-testid="button-get-certificate"
              >
                Get My Certificate!
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6">
      <Confetti isActive={showConfetti} />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-2xl"
      >
        <Card className="p-8 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 border-4 border-primary/30">
          <div className="text-center">
            <motion.div
              initial={{ y: -20 }}
              animate={{ y: 0 }}
              className="flex justify-center mb-4"
            >
              <Award className="w-20 h-20 text-primary" />
            </motion.div>

            <h1 className="text-3xl md:text-4xl font-black mb-2" data-testid="text-certificate-title">
              AI Teacher Certificate
            </h1>
            
            <p className="text-muted-foreground mb-6">This certifies that</p>
            
            <p className="text-4xl font-bold text-primary mb-6" data-testid="text-student-name">
              {studentName || "Amazing Student"}
            </p>
            
            <p className="text-lg mb-6">
              has successfully completed the Sporty Bot Machine Learning Training Program!
            </p>

            <div className="flex justify-center mb-6">
              <SportyBot mood="excited" size="md" showGradCap />
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6 max-w-sm mx-auto">
              <div className="bg-card p-3 rounded-lg">
                <p className="text-2xl font-bold text-primary">{trainingExamples}</p>
                <p className="text-xs text-muted-foreground">Examples Taught</p>
              </div>
              <div className="bg-card p-3 rounded-lg">
                <p className="text-2xl font-bold text-secondary">{finalAccuracy}%</p>
                <p className="text-xs text-muted-foreground">Final Accuracy</p>
              </div>
            </div>

            <p className="text-sm text-muted-foreground mb-6">
              {new Date().toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button onClick={downloadCertificate} data-testid="button-download">
                <Download className="w-4 h-4 mr-2" />
                Download Certificate
              </Button>
              <Button variant="outline" onClick={onRestart} data-testid="button-restart">
                <RotateCcw className="w-4 h-4 mr-2" />
                Play Again
              </Button>
            </div>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}

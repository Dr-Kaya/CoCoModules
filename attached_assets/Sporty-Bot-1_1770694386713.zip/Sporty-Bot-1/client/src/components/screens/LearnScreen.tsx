import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { SportyBot } from "@/components/SportyBot";
import { QuickCheck } from "@/components/QuickCheck";
import { SelfRegulatedCheck } from "@/components/SelfRegulatedCheck";
import { Play, SkipForward } from "lucide-react";

interface LearnScreenProps {
  onComplete: () => void;
  onAssessmentAnswer: (questionId: string, answer: string) => void;
}

type LearnStep = "intro" | "precheck" | "video" | "selfcheck" | "complete";

export function LearnScreen({ onComplete, onAssessmentAnswer }: LearnScreenProps) {
  const [step, setStep] = useState<LearnStep>("intro");
  const [videoProgress, setVideoProgress] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlayVideo = () => {
    setIsPlaying(true);
    const interval = setInterval(() => {
      setVideoProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setStep("selfcheck");
          return 100;
        }
        return prev + 5;
      });
    }, 250);
  };

  const mlSteps = [
    { icon: "📊", label: "Collect Data", desc: "Gather examples" },
    { icon: "🧠", label: "Train", desc: "Teach the model" },
    { icon: "🧪", label: "Test", desc: "Check accuracy" },
    { icon: "🔄", label: "Improve", desc: "Add more data" },
    { icon: "🚀", label: "Deploy", desc: "Use it!" }
  ];

  return (
    <div className="min-h-screen flex flex-col p-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-6"
      >
        <h1 className="text-3xl md:text-4xl font-bold text-foreground" data-testid="text-learn-title">
          Step 1: Learn About Machine Learning
        </h1>
        <p className="text-muted-foreground mt-2">
          Discover how computers can learn from examples!
        </p>
      </motion.div>

      <div className="flex-1 flex flex-col items-center justify-center max-w-4xl mx-auto w-full">
        {step === "intro" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="w-full"
          >
            <div className="flex justify-center mb-8">
              <SportyBot mood="excited" size="md" message="Let's learn how I can become smarter!" />
            </div>
            <Button
              size="lg"
              onClick={() => setStep("precheck")}
              className="mx-auto block"
              data-testid="button-begin-learn"
            >
              Begin Learning
            </Button>
          </motion.div>
        )}

        {step === "precheck" && (
          <QuickCheck
            question="How do you think a computer learns new things?"
            type="multiple"
            icon="🤔"
            options={[
              { value: "typed", label: "Someone types in all the answers", isCorrect: false },
              { value: "examples", label: "It learns from lots of examples", isCorrect: true },
              { value: "knows", label: "It already knows everything", isCorrect: false }
            ]}
            onAnswer={(answer) => {
              onAssessmentAnswer("precheck-learning", answer);
              setStep("video");
            }}
            feedback={{
              correct: "That's right! Computers learn from examples, just like you!",
              incorrect: "Good guess! Actually, computers learn from lots of examples, just like you learn from practice."
            }}
          />
        )}

        {step === "video" && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full space-y-6"
          >
            <Card className="aspect-video relative overflow-hidden bg-gradient-to-br from-primary/20 to-secondary/20">
              {!isPlaying ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <SportyBot mood="neutral" size="lg" />
                  <p className="text-lg font-medium mt-4 mb-4 text-foreground">
                    Watch this video to learn how machines learn!
                  </p>
                  <div className="flex gap-4">
                    <Button onClick={handlePlayVideo} size="lg" data-testid="button-play-video">
                      <Play className="w-5 h-5 mr-2" />
                      Play Video
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setStep("selfcheck")}
                      data-testid="button-skip-video"
                    >
                      <SkipForward className="w-5 h-5 mr-2" />
                      Skip
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-8">
                  <div className="flex gap-4 flex-wrap justify-center mb-8">
                    {mlSteps.map((s, i) => (
                      <motion.div
                        key={s.label}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: videoProgress > i * 20 ? 1 : 0.3, y: 0 }}
                        transition={{ delay: i * 0.5 }}
                        className="flex flex-col items-center"
                      >
                        <div className={`
                          w-16 h-16 rounded-full flex items-center justify-center text-3xl
                          ${videoProgress > i * 20 
                            ? 'bg-primary text-primary-foreground shadow-lg' 
                            : 'bg-muted'
                          }
                        `}>
                          {s.icon}
                        </div>
                        <p className="text-sm font-medium mt-2">{s.label}</p>
                        <p className="text-xs text-muted-foreground">{s.desc}</p>
                        {i < mlSteps.length - 1 && (
                          <div className="hidden md:block absolute" style={{ left: `${(i + 1) * 20}%` }}>
                            →
                          </div>
                        )}
                      </motion.div>
                    ))}
                  </div>
                  <Progress value={videoProgress} className="w-full max-w-md" />
                  <p className="text-sm text-muted-foreground mt-2">
                    Learning in progress... {Math.round(videoProgress)}%
                  </p>
                </div>
              )}
            </Card>

            <div className="flex justify-center gap-4 flex-wrap">
              {mlSteps.map((s, i) => (
                <motion.div
                  key={s.label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + i * 0.1 }}
                  className="flex items-center gap-2 bg-card rounded-full px-4 py-2 border border-card-border shadow-sm"
                >
                  <span className="text-xl">{s.icon}</span>
                  <span className="text-sm font-medium">{s.label}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {step === "selfcheck" && (
          <SelfRegulatedCheck
            type="brain"
            title="Brain Check!"
            prompt="Have you ever taught someone (or a pet) something new? This will help you understand how we teach AI!"
            options={[
              { value: "yes-person", label: "Yes, I taught a person", emoji: "👤" },
              { value: "yes-pet", label: "Yes, I taught a pet", emoji: "🐕" },
              { value: "no", label: "Not yet, but I can imagine it", emoji: "💭" }
            ]}
            onComplete={(response) => {
              if (response.selection) {
                onAssessmentAnswer("self-teaching-exp", response.selection);
              }
              onComplete();
            }}
          />
        )}
      </div>
    </div>
  );
}

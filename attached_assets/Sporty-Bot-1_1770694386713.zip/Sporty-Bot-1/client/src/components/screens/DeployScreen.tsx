import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { SportyBot } from "@/components/SportyBot";
import { Ball } from "@/components/Ball";
import { Confetti } from "@/components/Confetti";
import { CircularMLCycle } from "@/components/ProgressIndicator";
import { generateBalls, simulateBotClassification } from "@/lib/gameUtils";
import { PartyPopper, ArrowLeft, ArrowRight, Sparkles } from "lucide-react";
import type { Ball as BallType, BallType as BallTypeEnum } from "@shared/schema";

interface DeployScreenProps {
  trainingExamples: number;
  phase1Accuracy: number;
  phase2Accuracy: number;
  onContinue: () => void;
}

export function DeployScreen({ 
  trainingExamples, 
  phase1Accuracy, 
  phase2Accuracy,
  onContinue 
}: DeployScreenProps) {
  const [showConfetti, setShowConfetti] = useState(true);
  const [tryBalls] = useState<BallType[]>(() => generateBalls(12));
  const [selectedBallIndex, setSelectedBallIndex] = useState(0);
  const [tryResult, setTryResult] = useState<{ guess: BallTypeEnum; correct: boolean } | null>(null);
  const [isThinking, setIsThinking] = useState(false);

  const handlePickBall = (direction: "prev" | "next") => {
    setTryResult(null);
    if (direction === "prev") {
      setSelectedBallIndex(prev => prev === 0 ? tryBalls.length - 1 : prev - 1);
    } else {
      setSelectedBallIndex(prev => prev === tryBalls.length - 1 ? 0 : prev + 1);
    }
  };

  const handleAskSportyBot = () => {
    setIsThinking(true);
    setTryResult(null);
    
    setTimeout(() => {
      const ball = tryBalls[selectedBallIndex];
      const guess = simulateBotClassification(ball, trainingExamples);
      const correct = guess === ball.type;
      
      setTryResult({ guess, correct });
      setIsThinking(false);
    }, 1500);
  };

  const takeaways = [
    { icon: "🌟", text: "Machines learn from examples, just like you!" },
    { icon: "🌟", text: "More examples = better learning!" },
    { icon: "🌟", text: "Testing helps us see what to improve!" },
    { icon: "🌟", text: "YOU are the teacher - humans help AI learn!" }
  ];

  const selectedBall = tryBalls[selectedBallIndex];

  return (
    <div className="min-h-screen flex flex-col p-6 overflow-y-auto">
      <Confetti isActive={showConfetti} />

      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <div className="flex items-center justify-center gap-2 mb-4">
          <PartyPopper className="w-8 h-8 text-secondary" />
          <h1 className="text-3xl md:text-4xl font-bold text-foreground" data-testid="text-deploy-title">
            Sporty Bot is Ready!
          </h1>
          <PartyPopper className="w-8 h-8 text-secondary" />
        </div>
        <p className="text-lg text-muted-foreground">
          Congratulations! You've successfully trained an AI!
        </p>
      </motion.div>

      <div className="flex-1 flex flex-col items-center max-w-4xl mx-auto w-full space-y-8">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.3, type: "spring" }}
        >
          <SportyBot 
            mood="excited" 
            size="lg" 
            showGradCap 
            message="Thank you for teaching me! I can now tell the difference between basketballs and soccer balls!"
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="w-full"
        >
          <Card className="p-6 bg-gradient-to-br from-primary/10 to-secondary/10">
            <h2 className="text-xl font-bold mb-4 text-center">Your Training Summary</h2>
            <div className="grid md:grid-cols-3 gap-4 text-center">
              <div className="p-4 bg-card rounded-xl">
                <p className="text-3xl font-bold text-primary" data-testid="text-training-examples">{trainingExamples}</p>
                <p className="text-sm text-muted-foreground">Training Examples</p>
              </div>
              <div className="p-4 bg-card rounded-xl">
                <p className="text-3xl font-bold text-secondary" data-testid="text-confidence-improvement">{phase1Accuracy}% → {phase2Accuracy}%</p>
                <p className="text-sm text-muted-foreground">Confidence Improvement</p>
              </div>
              <div className="p-4 bg-card rounded-xl">
                <p className="text-3xl font-bold text-accent" data-testid="text-learning-gain">+{phase2Accuracy - phase1Accuracy}%</p>
                <p className="text-sm text-muted-foreground">Confidence Gain</p>
              </div>
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="w-full"
        >
          <Card className="p-6">
            <h2 className="text-xl font-bold mb-6 text-center">ML Lifecycle Complete!</h2>
            <div className="flex justify-center">
              <CircularMLCycle allComplete size="md" />
            </div>
            <p className="text-center text-muted-foreground mt-8 text-sm">
              The ML lifecycle is circular - you can always collect more data, retrain, and improve!
            </p>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
          className="w-full"
        >
          <Card className="p-6 bg-gradient-to-br from-secondary/10 to-accent/10">
            <h2 className="text-xl font-bold mb-2 text-center flex items-center justify-center gap-2">
              <Sparkles className="w-5 h-5 text-secondary" />
              Show Me a Ball!
              <Sparkles className="w-5 h-5 text-secondary" />
            </h2>
            <p className="text-center text-muted-foreground text-sm mb-6">
              Pick a ball and ask Sporty Bot to predict what type it is!
            </p>
            
            <div className="flex flex-col items-center gap-6">
              <div className="flex items-center gap-4">
                <Button 
                  size="icon" 
                  variant="outline"
                  onClick={() => handlePickBall("prev")}
                  disabled={isThinking}
                  data-testid="button-prev-ball"
                >
                  <ArrowLeft className="w-4 h-4" />
                </Button>
                
                <div className="relative">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={selectedBallIndex}
                      initial={{ opacity: 0, scale: 0.8, rotateY: -90 }}
                      animate={{ opacity: 1, scale: 1, rotateY: 0 }}
                      exit={{ opacity: 0, scale: 0.8, rotateY: 90 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Ball 
                        type={selectedBall.type} 
                        variant={selectedBall.variant}
                        size="lg"
                      />
                    </motion.div>
                  </AnimatePresence>
                  
                  <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-card px-3 py-1 rounded-full text-xs font-medium border">
                    Ball {selectedBallIndex + 1} of {tryBalls.length}
                  </div>
                </div>
                
                <Button 
                  size="icon" 
                  variant="outline"
                  onClick={() => handlePickBall("next")}
                  disabled={isThinking}
                  data-testid="button-next-ball"
                >
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="flex flex-col items-center gap-4 min-h-[120px]">
                {isThinking && (
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ repeat: Infinity, duration: 0.5 }}
                  >
                    <SportyBot mood="thinking" size="sm" message="Hmm, let me think..." />
                  </motion.div>
                )}
                
                {!isThinking && !tryResult && (
                  <Button 
                    onClick={handleAskSportyBot} 
                    className="gap-2"
                    data-testid="button-ask-predict"
                  >
                    <span>🤖</span>
                    Ask Sporty Bot to Predict!
                  </Button>
                )}
                
                {tryResult && (
                  <motion.div
                    initial={{ scale: 0, y: 20 }}
                    animate={{ scale: 1, y: 0 }}
                    className="flex flex-col items-center gap-3"
                  >
                    <SportyBot 
                      mood={tryResult.correct ? "happy" : "sad"} 
                      size="sm" 
                      message={tryResult.correct 
                        ? "I got it right!" 
                        : "Oops! I made a mistake."
                      }
                    />
                    <div
                      className={`
                        px-6 py-3 rounded-xl font-bold text-lg
                        ${tryResult.correct 
                          ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300' 
                          : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
                        }
                      `}
                    >
                      <span className="mr-2">{tryResult.correct ? '✓' : '✗'}</span>
                      I think it's a {tryResult.guess}!
                      {!tryResult.correct && (
                        <span className="text-sm block mt-1">
                          (It was actually a {selectedBall.type})
                        </span>
                      )}
                    </div>
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setTryResult(null);
                        handlePickBall("next");
                      }}
                      className="mt-2"
                      data-testid="button-try-another"
                    >
                      Try Another Ball!
                    </Button>
                  </motion.div>
                )}
              </div>
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="w-full"
        >
          <Card className="p-6 bg-gradient-to-br from-accent/10 to-primary/10">
            <h2 className="text-xl font-bold mb-4 text-center">Key Takeaways</h2>
            <div className="grid md:grid-cols-2 gap-3">
              {takeaways.map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 1.3 + i * 0.1 }}
                  className="flex items-center gap-2 p-3 bg-card rounded-lg"
                >
                  <span className="text-2xl">{item.icon}</span>
                  <span className="text-sm font-medium">{item.text}</span>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
        >
          <Button 
            size="lg" 
            onClick={onContinue}
            className="px-10"
            data-testid="button-final-assessment"
          >
            Final Quiz & Certificate!
          </Button>
        </motion.div>
      </div>
    </div>
  );
}

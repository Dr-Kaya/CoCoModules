import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { SportyBot } from "@/components/SportyBot";
import { Ball } from "@/components/Ball";
import { QuickCheck } from "@/components/QuickCheck";
import { SelfRegulatedCheck } from "@/components/SelfRegulatedCheck";
import { generateBalls, simulateBotClassification, calculateConfidence, getBotMood } from "@/lib/gameUtils";
import { Check, X } from "lucide-react";
import type { Ball as BallType, TestResult } from "@shared/schema";

interface TestScreenProps {
  phase: 1 | 2;
  trainingExamples: number;
  onComplete: (results: { accuracy: number; testResults: TestResult[] }) => void;
  onAssessmentAnswer: (questionId: string, answer: string) => void;
  previousAccuracy?: number;
  prediction?: string;
}

type TestStep = "intro" | "testing" | "results" | "reflection" | "complete";

export function TestScreen({ 
  phase, 
  trainingExamples, 
  onComplete, 
  onAssessmentAnswer,
  previousAccuracy = 0,
  prediction
}: TestScreenProps) {
  const [balls] = useState<BallType[]>(() => generateBalls(5));
  const [currentIndex, setCurrentIndex] = useState(0);
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [step, setStep] = useState<TestStep>("intro");
  const [showResult, setShowResult] = useState(false);

  const confidence = calculateConfidence(
    testResults.filter(r => r.correct).length,
    testResults.length
  );

  useEffect(() => {
    if (step === "testing" && currentIndex < balls.length) {
      const timer = setTimeout(() => {
        const ball = balls[currentIndex];
        const botGuess = simulateBotClassification(ball, trainingExamples);
        const isCorrect = botGuess === ball.type;

        setTestResults(prev => [...prev, {
          ballId: ball.id,
          ballType: ball.type,
          botClassification: botGuess,
          correct: isCorrect
        }]);

        setShowResult(true);

        setTimeout(() => {
          setShowResult(false);
          if (currentIndex + 1 >= balls.length) {
            setStep("results");
          } else {
            setCurrentIndex(prev => prev + 1);
          }
        }, 1500);
      }, 1000);

      return () => clearTimeout(timer);
    }
  }, [step, currentIndex, balls, trainingExamples]);

  const currentBall = balls[currentIndex];
  const currentResult = testResults[currentIndex];
  const botMood = getBotMood(confidence);

  if (step === "intro") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-lg"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-test-title">
            {phase === 1 ? "Step 3: Test Sporty Bot!" : "Step 5: Test Again!"}
          </h1>
          <p className="text-lg text-muted-foreground mb-8">
            Let's see if Sporty Bot learned! Watch as it tries to sort balls on its own.
          </p>
          
          <SportyBot 
            mood="thinking" 
            size="lg" 
            message={phase === 1 
              ? "I'll try my best! Here we go..." 
              : "I learned so much! Let me show you!"
            }
          />

          <Button
            size="lg"
            onClick={() => setStep("testing")}
            className="mt-8"
            data-testid="button-start-test"
          >
            Start Testing!
          </Button>
        </motion.div>
      </div>
    );
  }

  if (step === "testing") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center w-full max-w-lg"
        >
          <h2 className="text-2xl font-bold mb-6">
            Testing Ball {currentIndex + 1} of {balls.length}
          </h2>
          
          <Progress value={(currentIndex / balls.length) * 100} className="mb-8" />

          <div className="flex flex-col items-center gap-6">
            <AnimatePresence mode="wait">
              {currentBall && (
                <motion.div
                  key={currentBall.id}
                  initial={{ opacity: 0, y: -30 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 30 }}
                  className="flex flex-col items-center"
                >
                  <Ball type={currentBall.type} variant={currentBall.variant} size="lg" />
                  
                  {!showResult && (
                    <motion.div
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ repeat: Infinity, duration: 0.5 }}
                      className="mt-4"
                    >
                      <SportyBot mood="thinking" size="sm" message="Hmm, let me think..." />
                    </motion.div>
                  )}

                  {showResult && currentResult && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className={`
                        mt-4 p-4 rounded-xl flex items-center gap-3
                        ${currentResult.correct 
                          ? 'bg-green-100 dark:bg-green-900/30' 
                          : 'bg-red-100 dark:bg-red-900/30'
                        }
                      `}
                    >
                      {currentResult.correct ? (
                        <Check className="w-8 h-8 text-green-600" />
                      ) : (
                        <X className="w-8 h-8 text-red-600" />
                      )}
                      <div className="text-left">
                        <p className="font-bold">
                          {currentResult.correct ? "Correct!" : "Wrong!"}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Sporty Bot guessed: {currentResult.botClassification}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    );
  }

  if (step === "results") {
    const correctCount = testResults.filter(r => r.correct).length;
    
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center w-full max-w-2xl"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
            Test Results!
          </h1>

          <div className="flex justify-center mb-6">
            <SportyBot 
              mood={botMood} 
              size="lg" 
              message={
                confidence >= 80 
                  ? "Wow! I'm super confident now! Thank you!" 
                  : "Hmm, I made some mistakes. Can you teach me more?"
              }
            />
          </div>

          <Card className="p-6 mb-6">
            <div className="text-4xl font-bold mb-2" data-testid="text-correct-count">
              {correctCount} out of {balls.length} correct!
            </div>
            <p className="text-muted-foreground text-sm mb-2">Confidence Level:</p>
            <div className={`
              text-6xl font-black
              ${confidence >= 80 ? 'text-green-500' : confidence >= 50 ? 'text-yellow-500' : 'text-red-500'}
            `} data-testid="text-confidence">
              {confidence}%
            </div>
            
            <div className="flex justify-center gap-2 mt-4">
              {testResults.map((result, i) => (
                <div
                  key={i}
                  className={`
                    w-10 h-10 rounded-full flex items-center justify-center
                    ${result.correct 
                      ? 'bg-green-100 dark:bg-green-900/30' 
                      : 'bg-red-100 dark:bg-red-900/30'
                    }
                  `}
                >
                  {result.correct ? (
                    <Check className="w-5 h-5 text-green-600" />
                  ) : (
                    <X className="w-5 h-5 text-red-600" />
                  )}
                </div>
              ))}
            </div>
          </Card>

          {phase === 2 && (
            <Card className="p-4 mb-6 bg-gradient-to-r from-primary/10 to-secondary/10">
              <h3 className="font-bold mb-2">Confidence Improvement</h3>
              <div className="flex justify-around items-center">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Before</p>
                  <p className="text-2xl font-bold">{previousAccuracy}%</p>
                  <p className="text-xs text-muted-foreground">8 examples</p>
                </div>
                <div className="text-3xl">→</div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">After</p>
                  <p className="text-2xl font-bold text-primary">{confidence}%</p>
                  <p className="text-xs text-muted-foreground">{trainingExamples} examples</p>
                </div>
              </div>
            </Card>
          )}

          <Button
            size="lg"
            onClick={() => setStep("reflection")}
            data-testid="button-continue-reflection"
          >
            Continue
          </Button>
        </motion.div>
      </div>
    );
  }

  if (step === "reflection") {
    if (phase === 1) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center p-6">
          <QuickCheck
            question="Sporty Bot made some mistakes. What might help it get better?"
            type="multiple"
            icon="🤔"
            options={[
              { value: "more-examples", label: "Give it more examples to learn from", isCorrect: true },
              { value: "yell", label: "Yell at it louder", isCorrect: false },
              { value: "give-up", label: "Give up", isCorrect: false }
            ]}
            onAnswer={(answer) => {
              onAssessmentAnswer("improvement-strategy", answer);
              onComplete({ accuracy: confidence, testResults });
            }}
            feedback={{
              correct: "Yes! Just like how you get better with practice, AI needs more examples to learn!",
              incorrect: "Actually, giving more examples helps! Just like practice makes you better."
            }}
          />
        </div>
      );
    }

    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6">
        <SelfRegulatedCheck
          type="reflection"
          title="Making Connections"
          prompt="How is YOUR learning similar to how Sporty Bot learned?"
          options={[
            { value: "practice", label: "Practice makes me better too!", emoji: "🎯" },
            { value: "examples", label: "I also learn from examples", emoji: "📚" },
            { value: "mistakes", label: "Making mistakes helps me learn", emoji: "💡" }
          ]}
          allowText
          onComplete={(response) => {
            if (response.selection) {
              onAssessmentAnswer("learning-connection", response.selection);
            }
            onComplete({ accuracy: confidence, testResults });
          }}
        />
      </div>
    );
  }

  return null;
}

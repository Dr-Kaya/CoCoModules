import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { SportyBot } from "@/components/SportyBot";
import { Ball } from "@/components/Ball";

interface WelcomeScreenProps {
  onStart: () => void;
}

export function WelcomeScreen({ onStart }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-b from-background via-primary/5 to-secondary/5">
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mb-8"
      >
        <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2" data-testid="text-welcome-title">
          Welcome to
        </h1>
        <h2 className="text-5xl md:text-6xl font-black bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent" data-testid="text-app-name">
          Sporty Bot!
        </h2>
      </motion.div>

      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.3, type: "spring", stiffness: 200 }}
        className="mb-8"
      >
        <SportyBot 
          mood="happy" 
          size="lg" 
          message="Hi! I'm Sporty Bot, but I have a problem... I can't tell the difference between basketballs and soccer balls! Can you teach me?"
        />
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="flex gap-6 mb-10"
      >
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity, delay: 0 }}
        >
          <Ball type="basketball" size="md" />
        </motion.div>
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
        >
          <Ball type="soccer" size="md" />
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9 }}
        className="flex flex-col items-center gap-4"
      >
        <div className="bg-card border border-card-border rounded-2xl p-6 shadow-lg max-w-md text-center mb-4">
          <p className="text-lg font-semibold text-foreground mb-4">
            Today you will:
          </p>
          <ul className="space-y-2 text-left">
            <li className="flex items-center gap-2">
              <span className="text-xl">✨</span>
              <span className="text-muted-foreground">Learn how machines learn from examples</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="text-xl">✨</span>
              <span className="text-muted-foreground">Teach Sporty Bot to recognize different balls</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="text-xl">✨</span>
              <span className="text-muted-foreground">See how practice makes AI better!</span>
            </li>
          </ul>
        </div>

        <Button 
          size="lg"
          onClick={onStart}
          className="text-xl px-10 py-6 rounded-full shadow-lg"
          data-testid="button-start"
        >
          I'm Ready to Be an AI Teacher!
        </Button>
      </motion.div>

      <motion.div
        className="absolute bottom-0 left-0 right-0 h-32 pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <svg viewBox="0 0 1200 120" className="w-full h-full" preserveAspectRatio="none">
          <path d="M0,60 C300,100 600,20 900,60 C1050,80 1150,40 1200,60 L1200,120 L0,120 Z" fill="hsl(var(--primary) / 0.1)" />
          <path d="M0,80 C400,40 800,100 1200,60 L1200,120 L0,120 Z" fill="hsl(var(--secondary) / 0.1)" />
        </svg>
      </motion.div>
    </div>
  );
}

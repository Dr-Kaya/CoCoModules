import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";

interface SelfRegulatedCheckProps {
  type: "brain" | "goal" | "strategy" | "success" | "reflection";
  title: string;
  prompt: string;
  options?: { value: string; label: string; emoji?: string }[];
  allowText?: boolean;
  onComplete: (response: { selection?: string; text?: string }) => void;
}

const typeConfig = {
  brain: { emoji: "🧠", color: "from-purple-500/20 to-purple-600/10" },
  goal: { emoji: "🎯", color: "from-blue-500/20 to-blue-600/10" },
  strategy: { emoji: "🔄", color: "from-green-500/20 to-green-600/10" },
  success: { emoji: "⭐", color: "from-yellow-500/20 to-yellow-600/10" },
  reflection: { emoji: "💭", color: "from-pink-500/20 to-pink-600/10" }
};

export function SelfRegulatedCheck({
  type,
  title,
  prompt,
  options = [],
  allowText = false,
  onComplete
}: SelfRegulatedCheckProps) {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [textResponse, setTextResponse] = useState("");
  
  const config = typeConfig[type];

  const handleComplete = () => {
    onComplete({
      selection: selectedOption || undefined,
      text: textResponse || undefined
    });
  };

  const canSubmit = selectedOption || textResponse.trim().length > 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-lg mx-auto"
    >
      <Card className={`p-6 bg-gradient-to-br ${config.color} border-2 border-primary/20`}>
        <div className="flex items-center gap-3 mb-4">
          <span className="text-4xl">{config.emoji}</span>
          <div>
            <h3 className="text-lg font-bold text-foreground">{title}</h3>
            <p className="text-sm text-muted-foreground">{prompt}</p>
          </div>
        </div>

        {options.length > 0 && (
          <div className="space-y-2 mb-4">
            {options.map((option) => (
              <Button
                key={option.value}
                variant={selectedOption === option.value ? "default" : "outline"}
                className="w-full justify-start h-auto py-3 px-4"
                onClick={() => setSelectedOption(option.value)}
                data-testid={`self-reg-${option.value}`}
              >
                {option.emoji && <span className="mr-2 text-lg">{option.emoji}</span>}
                {option.label}
              </Button>
            ))}
          </div>
        )}

        {allowText && (
          <Textarea
            placeholder="Share your thoughts..."
            value={textResponse}
            onChange={(e) => setTextResponse(e.target.value)}
            className="mb-4 min-h-[80px]"
            data-testid="self-reg-text"
          />
        )}

        <Button
          onClick={handleComplete}
          disabled={!canSubmit}
          className="w-full"
          data-testid="self-reg-submit"
        >
          Continue
        </Button>
      </Card>
    </motion.div>
  );
}

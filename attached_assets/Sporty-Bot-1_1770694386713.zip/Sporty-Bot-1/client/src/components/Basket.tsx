import { motion } from "framer-motion";
import type { BallType } from "@shared/schema";

interface BasketProps {
  type: BallType;
  isActive?: boolean;
  isHovered?: boolean;
  ballCount?: number;
  onDrop?: () => void;
}

export function Basket({ type, isActive = false, isHovered = false, ballCount = 0 }: BasketProps) {
  const isBasketball = type === "basketball";
  
  return (
    <motion.div
      className={`
        relative flex flex-col items-center gap-2 p-4 rounded-2xl
        transition-all duration-200 min-w-[140px]
        ${isActive 
          ? 'ring-4 ring-primary shadow-lg' 
          : isHovered
            ? 'ring-4 ring-secondary shadow-xl'
            : 'shadow-md hover:shadow-lg'
        }
        ${isBasketball 
          ? 'bg-gradient-to-b from-orange-100 to-orange-200 dark:from-orange-900/30 dark:to-orange-800/30' 
          : 'bg-gradient-to-b from-gray-100 to-gray-200 dark:from-gray-800/50 dark:to-gray-700/50'
        }
      `}
      animate={{ 
        scale: isActive ? 1.1 : isHovered ? 1.15 : 1,
        y: isHovered ? -8 : 0
      }}
      transition={{ type: "spring", stiffness: 400, damping: 25 }}
      data-testid={`basket-${type}`}
    >
      <div className="absolute -top-3 left-1/2 -translate-x-1/2">
        <span className={`
          text-3xl px-3 py-1 rounded-full shadow-sm
          ${isBasketball 
            ? 'bg-orange-400 dark:bg-orange-600' 
            : 'bg-gray-300 dark:bg-gray-600'
          }
        `}>
          {isBasketball ? '🏀' : '⚽'}
        </span>
      </div>
      
      {ballCount > 0 && (
        <motion.div 
          className={`
            absolute -top-2 -right-2 w-8 h-8 rounded-full
            flex items-center justify-center text-sm font-bold
            ${isBasketball 
              ? 'bg-orange-500 text-white' 
              : 'bg-gray-600 text-white'
            }
          `}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          key={ballCount}
        >
          {ballCount}
        </motion.div>
      )}
      
      <svg viewBox="0 0 120 80" className="w-28 h-20 mt-6">
        <defs>
          <linearGradient id={`basket-${type}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={isBasketball ? "#D97706" : "#6B7280"} />
            <stop offset="100%" stopColor={isBasketball ? "#92400E" : "#374151"} />
          </linearGradient>
        </defs>
        
        <path 
          d="M 10 10 L 20 70 L 100 70 L 110 10 Z" 
          fill={`url(#basket-${type})`}
          stroke={isBasketball ? "#78350F" : "#1F2937"}
          strokeWidth="3"
        />
        
        <line x1="35" y1="10" x2="40" y2="70" stroke={isBasketball ? "#78350F" : "#1F2937"} strokeWidth="2" opacity="0.5" />
        <line x1="60" y1="10" x2="60" y2="70" stroke={isBasketball ? "#78350F" : "#1F2937"} strokeWidth="2" opacity="0.5" />
        <line x1="85" y1="10" x2="80" y2="70" stroke={isBasketball ? "#78350F" : "#1F2937"} strokeWidth="2" opacity="0.5" />
        
        <line x1="20" y1="30" x2="100" y2="30" stroke={isBasketball ? "#78350F" : "#1F2937"} strokeWidth="2" opacity="0.5" />
        <line x1="20" y1="50" x2="100" y2="50" stroke={isBasketball ? "#78350F" : "#1F2937"} strokeWidth="2" opacity="0.5" />
      </svg>
      
      <span className={`
        text-base font-bold mt-1
        ${isBasketball 
          ? 'text-orange-700 dark:text-orange-300' 
          : 'text-gray-700 dark:text-gray-300'
        }
      `}>
        {isBasketball ? 'Basketball' : 'Soccer Ball'}
      </span>
    </motion.div>
  );
}

import { motion } from "framer-motion";
import type { BallType } from "@shared/schema";

interface BallProps {
  type: BallType;
  variant?: number;
  size?: "sm" | "md" | "lg";
  draggable?: boolean;
  onDragStart?: () => void;
  onDragEnd?: () => void;
  className?: string;
}

const ballVariations = [
  { rotation: 0, scale: 1.0, perspective: "front", brightness: 1.0 },
  { rotation: 15, scale: 0.85, perspective: "far", brightness: 0.95 },
  { rotation: -20, scale: 1.1, perspective: "close", brightness: 1.05 },
  { rotation: 30, scale: 0.9, perspective: "angled-left", brightness: 0.9 },
  { rotation: -35, scale: 0.95, perspective: "angled-right", brightness: 1.0 },
  { rotation: 45, scale: 1.15, perspective: "very-close", brightness: 1.1 },
  { rotation: -10, scale: 0.8, perspective: "distant", brightness: 0.85 },
  { rotation: 25, scale: 1.05, perspective: "tilted", brightness: 0.98 },
];

export function Ball({ 
  type, 
  variant = 1, 
  size = "md",
  draggable = false,
  onDragStart,
  onDragEnd,
  className = ""
}: BallProps) {
  const sizeClasses = {
    sm: "w-16 h-16",
    md: "w-24 h-24",
    lg: "w-32 h-32"
  };

  const variation = ballVariations[(variant - 1) % ballVariations.length];
  const { rotation, scale, perspective, brightness } = variation;
  
  const skewX = perspective.includes("angled-left") ? -8 : 
                perspective.includes("angled-right") ? 8 : 
                perspective === "tilted" ? 5 : 0;
  const skewY = perspective === "tilted" ? -3 : 0;

  if (type === "basketball") {
    const gradCx = perspective.includes("left") ? "20%" : perspective.includes("right") ? "40%" : "30%";
    const gradCy = perspective === "close" || perspective === "very-close" ? "25%" : "30%";
    const baseColor = brightness > 1 ? "#FFA070" : brightness < 0.95 ? "#E85A30" : "#FF6B35";
    const highlightColor = brightness > 1 ? "#FFB080" : brightness < 0.95 ? "#EE7550" : "#FF8A5B";
    
    return (
      <motion.div
        className={`${sizeClasses[size]} ${className} ${draggable ? 'cursor-grab active:cursor-grabbing' : ''}`}
        style={{ 
          transform: `rotate(${rotation}deg) scale(${scale}) skewX(${skewX}deg) skewY(${skewY}deg)`,
          filter: `brightness(${brightness})`
        }}
        whileHover={draggable ? { scale: scale * 1.1 } : undefined}
        whileTap={draggable ? { scale: scale * 0.95 } : undefined}
        drag={draggable}
        dragSnapToOrigin
        onDragStart={onDragStart}
        onDragEnd={onDragEnd}
        data-testid="ball-basketball"
      >
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-lg">
          <defs>
            <radialGradient id={`basketball-grad-${variant}`} cx={gradCx} cy={gradCy} r="70%">
              <stop offset="0%" stopColor={highlightColor} />
              <stop offset="100%" stopColor={baseColor} />
            </radialGradient>
          </defs>
          <circle cx="50" cy="50" r="48" fill={`url(#basketball-grad-${variant})`} stroke="#CC5522" strokeWidth="2" />
          <path d="M 50 2 Q 50 50 50 98" stroke="#1a1a2e" strokeWidth="2.5" fill="none" opacity={0.8 + (variant % 3) * 0.1} />
          <path d="M 2 50 Q 50 50 98 50" stroke="#1a1a2e" strokeWidth="2.5" fill="none" opacity={0.8 + (variant % 3) * 0.1} />
          <path d={`M ${15 + skewX} 15 Q 50 ${35 + skewY} ${85 - skewX} 15`} stroke="#1a1a2e" strokeWidth="2.5" fill="none" />
          <path d={`M ${15 + skewX} 85 Q 50 ${65 - skewY} ${85 - skewX} 85`} stroke="#1a1a2e" strokeWidth="2.5" fill="none" />
        </svg>
      </motion.div>
    );
  }

  const gradCx = perspective.includes("left") ? "20%" : perspective.includes("right") ? "40%" : "30%";
  const gradCy = perspective === "close" || perspective === "very-close" ? "25%" : "30%";
  const baseWhite = brightness > 1 ? "#FFFFFF" : brightness < 0.95 ? "#E0E0E0" : "#F5F5F5";
  const shadowWhite = brightness > 1 ? "#F0F0F0" : brightness < 0.95 ? "#D0D0D0" : "#E8E8E8";
  
  const pentagonOffset = (variant % 4) * 3;
  
  return (
    <motion.div
      className={`${sizeClasses[size]} ${className} ${draggable ? 'cursor-grab active:cursor-grabbing' : ''}`}
      style={{ 
        transform: `rotate(${rotation}deg) scale(${scale}) skewX(${skewX}deg) skewY(${skewY}deg)`,
        filter: `brightness(${brightness})`
      }}
      whileHover={draggable ? { scale: scale * 1.1 } : undefined}
      whileTap={draggable ? { scale: scale * 0.95 } : undefined}
      drag={draggable}
      dragSnapToOrigin
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      data-testid="ball-soccer"
    >
      <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-lg">
        <defs>
          <radialGradient id={`soccer-grad-${variant}`} cx={gradCx} cy={gradCy} r="70%">
            <stop offset="0%" stopColor={baseWhite} />
            <stop offset="100%" stopColor={shadowWhite} />
          </radialGradient>
        </defs>
        <circle cx="50" cy="50" r="48" fill={`url(#soccer-grad-${variant})`} stroke="#333" strokeWidth="2" />
        <polygon points={`${50+pentagonOffset},${20-pentagonOffset/2} ${65+pentagonOffset/2},35 ${60},${55+pentagonOffset/3} ${40},${55+pentagonOffset/3} ${35-pentagonOffset/2},35`} fill="#1a1a2e" />
        <polygon points={`${80-pentagonOffset/2},${45+pentagonOffset/3} ${85},${60} ${75+pentagonOffset/3},${75-pentagonOffset/2} ${60},${70} ${60},${55}`} fill="#1a1a2e" />
        <polygon points={`${20+pentagonOffset/2},${45+pentagonOffset/3} ${15},${60} ${25-pentagonOffset/3},${75-pentagonOffset/2} ${40},${70} ${40},${55}`} fill="#1a1a2e" />
        <polygon points={`35,${80+pentagonOffset/2} 50,${90-pentagonOffset/3} 65,${80+pentagonOffset/2} 60,70 40,70`} fill="#1a1a2e" />
        <polygon points={`${35-pentagonOffset/2},${20} ${50},${10+pentagonOffset/2} ${50},${20} ${35},35 ${25},${25}`} fill="#1a1a2e" opacity={0.9} />
        <polygon points={`${65+pentagonOffset/2},${20} ${50},${10+pentagonOffset/2} ${50},${20} ${65},35 ${75},${25}`} fill="#1a1a2e" opacity={0.9} />
      </svg>
    </motion.div>
  );
}

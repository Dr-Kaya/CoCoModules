import { motion } from "framer-motion";

interface SportyBotProps {
  mood?: "happy" | "neutral" | "sad" | "thinking" | "excited";
  message?: string;
  size?: "sm" | "md" | "lg";
  showGradCap?: boolean;
}

export function SportyBot({ 
  mood = "neutral", 
  message, 
  size = "md",
  showGradCap = false
}: SportyBotProps) {
  const sizeClasses = {
    sm: "w-20 h-20",
    md: "w-32 h-32",
    lg: "w-48 h-48"
  };

  const getMoodEmoji = () => {
    switch (mood) {
      case "happy":
        return (
          <g>
            <circle cx="35" cy="40" r="5" fill="#1a1a2e" />
            <circle cx="65" cy="40" r="5" fill="#1a1a2e" />
            <path d="M 30 60 Q 50 80 70 60" stroke="#1a1a2e" strokeWidth="4" fill="none" strokeLinecap="round" />
          </g>
        );
      case "excited":
        return (
          <g>
            <ellipse cx="35" cy="40" rx="6" ry="8" fill="#1a1a2e" />
            <ellipse cx="65" cy="40" rx="6" ry="8" fill="#1a1a2e" />
            <circle cx="37" cy="38" r="2" fill="white" />
            <circle cx="67" cy="38" r="2" fill="white" />
            <path d="M 25 58 Q 50 85 75 58" stroke="#1a1a2e" strokeWidth="4" fill="none" strokeLinecap="round" />
          </g>
        );
      case "sad":
        return (
          <g>
            <circle cx="35" cy="40" r="5" fill="#1a1a2e" />
            <circle cx="65" cy="40" r="5" fill="#1a1a2e" />
            <path d="M 30 70 Q 50 55 70 70" stroke="#1a1a2e" strokeWidth="4" fill="none" strokeLinecap="round" />
          </g>
        );
      case "thinking":
        return (
          <g>
            <circle cx="35" cy="40" r="5" fill="#1a1a2e" />
            <circle cx="65" cy="40" r="5" fill="#1a1a2e" />
            <ellipse cx="50" cy="65" rx="8" ry="5" fill="#1a1a2e" />
          </g>
        );
      default:
        return (
          <g>
            <circle cx="35" cy="40" r="5" fill="#1a1a2e" />
            <circle cx="65" cy="40" r="5" fill="#1a1a2e" />
            <line x1="35" y1="62" x2="65" y2="62" stroke="#1a1a2e" strokeWidth="4" strokeLinecap="round" />
          </g>
        );
    }
  };

  return (
    <div className="flex flex-col items-center gap-2">
      <motion.div 
        className={`relative ${sizeClasses[size]}`}
        animate={{ 
          y: [0, -5, 0],
        }}
        transition={{ 
          duration: 2, 
          repeat: Infinity, 
          ease: "easeInOut" 
        }}
      >
        {showGradCap && (
          <motion.div 
            className="absolute -top-8 left-1/2 -translate-x-1/2 z-10"
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5, type: "spring" }}
          >
            <svg viewBox="0 0 60 40" className="w-16 h-12">
              <polygon points="30,5 55,18 30,31 5,18" fill="#1a1a2e" />
              <rect x="27" y="20" width="6" height="15" fill="#1a1a2e" />
              <circle cx="30" cy="35" r="4" fill="#FFD700" />
              <line x1="30" y1="35" x2="45" y2="42" stroke="#FFD700" strokeWidth="2" />
              <circle cx="45" cy="44" r="3" fill="#FFD700" />
            </svg>
          </motion.div>
        )}
        
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-lg">
          <defs>
            <linearGradient id="botBody" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#4ECDC4" />
              <stop offset="100%" stopColor="#44B8AC" />
            </linearGradient>
            <linearGradient id="antenna" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FF6B35" />
              <stop offset="100%" stopColor="#FF8A5B" />
            </linearGradient>
          </defs>
          
          <rect x="5" y="10" width="90" height="80" rx="20" fill="url(#botBody)" />
          
          <rect x="20" y="25" width="60" height="50" rx="10" fill="#E8F4F8" />
          
          {getMoodEmoji()}
          
          <rect x="45" y="2" width="10" height="12" rx="2" fill="url(#antenna)" />
          <circle cx="50" cy="2" r="5" fill="#FF6B35">
            <animate attributeName="opacity" values="1;0.5;1" dur="1s" repeatCount="indefinite" />
          </circle>
          
          <rect x="0" y="40" width="8" height="20" rx="4" fill="url(#botBody)" />
          <rect x="92" y="40" width="8" height="20" rx="4" fill="url(#botBody)" />
        </svg>
      </motion.div>
      
      {message && (
        <motion.div 
          className="bg-card border border-card-border rounded-xl px-4 py-2 shadow-md max-w-xs text-center"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          key={message}
        >
          <p className="text-sm font-medium text-foreground">{message}</p>
        </motion.div>
      )}
    </div>
  );
}

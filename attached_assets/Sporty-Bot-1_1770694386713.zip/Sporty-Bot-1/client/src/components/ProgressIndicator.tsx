import { motion } from "framer-motion";
import { Check } from "lucide-react";
import type { GamePhase } from "@shared/schema";

interface ProgressIndicatorProps {
  currentPhase: GamePhase;
  variant?: "linear" | "circular";
}

const mlCyclePhases = [
  { id: "collect", label: "Collect", icon: "📊" },
  { id: "train", label: "Train", icon: "🧠" },
  { id: "test", label: "Test", icon: "🧪" },
  { id: "improve", label: "Improve", icon: "🔄" },
  { id: "deploy", label: "Deploy", icon: "🚀" }
];

const gamePhases = [
  { id: "welcome", label: "Start", icon: "🚀", mlStep: -1 },
  { id: "learn", label: "Learn", icon: "📚", mlStep: 0 },
  { id: "train1", label: "Train", icon: "🧠", mlStep: 1 },
  { id: "test1", label: "Test", icon: "🧪", mlStep: 2 },
  { id: "train2", label: "Train+", icon: "🧠", mlStep: 3 },
  { id: "test2", label: "Test+", icon: "🧪", mlStep: 2 },
  { id: "deploy", label: "Deploy", icon: "🎉", mlStep: 4 },
  { id: "assessment", label: "Review", icon: "⭐", mlStep: 4 }
];

export function ProgressIndicator({ currentPhase, variant = "linear" }: ProgressIndicatorProps) {
  const currentGameIndex = gamePhases.findIndex(p => p.id === currentPhase);
  const currentMLStep = gamePhases[currentGameIndex]?.mlStep ?? -1;

  if (variant === "circular") {
    return <CircularMLCycle currentStep={currentMLStep} />;
  }

  return (
    <div className="w-full px-4 py-3">
      <div className="flex items-center justify-between max-w-3xl mx-auto">
        {gamePhases.map((phase, index) => {
          const isCompleted = index < currentGameIndex;
          const isCurrent = index === currentGameIndex;
          
          return (
            <div key={phase.id} className="flex items-center">
              <motion.div
                className={`
                  relative flex items-center justify-center w-10 h-10 rounded-full
                  text-lg font-bold transition-all duration-300
                  ${isCompleted 
                    ? 'bg-primary text-primary-foreground' 
                    : isCurrent 
                      ? 'bg-secondary text-secondary-foreground ring-4 ring-secondary/30' 
                      : 'bg-muted text-muted-foreground'
                  }
                `}
                animate={isCurrent ? { scale: [1, 1.1, 1] } : {}}
                transition={{ duration: 1, repeat: isCurrent ? Infinity : 0 }}
              >
                {isCompleted ? (
                  <Check className="w-5 h-5" />
                ) : (
                  <span className="text-base">{phase.icon}</span>
                )}
              </motion.div>
              
              {index < gamePhases.length - 1 && (
                <div className={`
                  w-4 sm:w-8 h-1 mx-1
                  ${index < currentGameIndex 
                    ? 'bg-primary' 
                    : 'bg-muted'
                  }
                `} />
              )}
            </div>
          );
        })}
      </div>
      
      <div className="text-center mt-2">
        <span className="text-sm font-medium text-muted-foreground">
          {gamePhases[currentGameIndex]?.label || ""}
        </span>
      </div>
    </div>
  );
}

interface CircularMLCycleProps {
  currentStep?: number;
  allComplete?: boolean;
  size?: "sm" | "md" | "lg";
}

export function CircularMLCycle({ currentStep = -1, allComplete = false, size = "md" }: CircularMLCycleProps) {
  const sizeConfig = {
    sm: { radius: 60, nodeSize: 36, fontSize: "text-sm", iconSize: "text-base" },
    md: { radius: 90, nodeSize: 48, fontSize: "text-base", iconSize: "text-xl" },
    lg: { radius: 120, nodeSize: 56, fontSize: "text-lg", iconSize: "text-2xl" }
  };
  
  const config = sizeConfig[size];
  const { radius, nodeSize } = config;
  const centerX = radius + nodeSize / 2 + 10;
  const centerY = radius + nodeSize / 2 + 10;
  const totalSize = (radius + nodeSize / 2 + 10) * 2;

  return (
    <div className="relative" style={{ width: totalSize, height: totalSize }}>
      <svg 
        className="absolute inset-0" 
        width={totalSize} 
        height={totalSize}
        style={{ zIndex: 0 }}
      >
        <circle
          cx={centerX}
          cy={centerY}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth="3"
          className="text-muted/30"
          strokeDasharray="8 4"
        />
        
        {mlCyclePhases.map((_, index) => {
          const nextIndex = (index + 1) % mlCyclePhases.length;
          const angle1 = (index * 360 / mlCyclePhases.length - 90) * Math.PI / 180;
          const angle2 = (nextIndex * 360 / mlCyclePhases.length - 90) * Math.PI / 180;
          
          const x1 = centerX + Math.cos(angle1) * radius;
          const y1 = centerY + Math.sin(angle1) * radius;
          const x2 = centerX + Math.cos(angle2) * radius;
          const y2 = centerY + Math.sin(angle2) * radius;
          
          const midAngle = ((index + 0.5) * 360 / mlCyclePhases.length - 90) * Math.PI / 180;
          const ctrlX = centerX + Math.cos(midAngle) * (radius + 15);
          const ctrlY = centerY + Math.sin(midAngle) * (radius + 15);
          
          const isCompleted = allComplete || index < currentStep;
          
          return (
            <g key={`arrow-${index}`}>
              <path
                d={`M ${x1} ${y1} Q ${ctrlX} ${ctrlY} ${x2} ${y2}`}
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className={isCompleted ? "text-primary" : "text-muted/40"}
                markerEnd={`url(#arrowhead-${isCompleted ? 'active' : 'inactive'})`}
              />
            </g>
          );
        })}
        
        <defs>
          <marker
            id="arrowhead-active"
            markerWidth="10"
            markerHeight="7"
            refX="9"
            refY="3.5"
            orient="auto"
          >
            <polygon points="0 0, 10 3.5, 0 7" className="fill-primary" />
          </marker>
          <marker
            id="arrowhead-inactive"
            markerWidth="10"
            markerHeight="7"
            refX="9"
            refY="3.5"
            orient="auto"
          >
            <polygon points="0 0, 10 3.5, 0 7" className="fill-muted/40" />
          </marker>
        </defs>
      </svg>
      
      {mlCyclePhases.map((phase, index) => {
        const angle = (index * 360 / mlCyclePhases.length - 90) * Math.PI / 180;
        const x = centerX + Math.cos(angle) * radius - nodeSize / 2;
        const y = centerY + Math.sin(angle) * radius - nodeSize / 2;
        
        const isCompleted = allComplete || index < currentStep;
        const isCurrent = index === currentStep;
        
        return (
          <motion.div
            key={phase.id}
            className="absolute flex flex-col items-center"
            style={{ 
              left: x, 
              top: y, 
              width: nodeSize, 
              height: nodeSize,
              zIndex: 10
            }}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ 
              scale: 1, 
              opacity: 1,
              ...(isCurrent ? { scale: [1, 1.1, 1] } : {})
            }}
            transition={{ 
              delay: index * 0.1,
              duration: isCurrent ? 1 : 0.3,
              repeat: isCurrent ? Infinity : 0
            }}
          >
            <div
              className={`
                flex items-center justify-center rounded-full
                ${config.iconSize} font-bold transition-all duration-300
                ${isCompleted 
                  ? 'bg-primary text-primary-foreground shadow-lg' 
                  : isCurrent 
                    ? 'bg-secondary text-secondary-foreground ring-4 ring-secondary/30 shadow-lg' 
                    : 'bg-card border-2 border-muted text-muted-foreground'
                }
              `}
              style={{ width: nodeSize, height: nodeSize }}
            >
              {isCompleted && !isCurrent ? (
                <Check className="w-5 h-5" />
              ) : (
                <span>{phase.icon}</span>
              )}
            </div>
            <span className={`
              absolute -bottom-6 whitespace-nowrap font-medium
              ${config.fontSize}
              ${isCurrent ? 'text-primary' : isCompleted ? 'text-foreground' : 'text-muted-foreground'}
            `}>
              {phase.label}
            </span>
          </motion.div>
        );
      })}
      
      <div 
        className="absolute flex items-center justify-center"
        style={{ 
          left: centerX - 30, 
          top: centerY - 30, 
          width: 60, 
          height: 60 
        }}
      >
        <div className="text-center">
          <span className="text-2xl">🤖</span>
          <p className="text-xs font-bold text-muted-foreground">ML</p>
        </div>
      </div>
    </div>
  );
}

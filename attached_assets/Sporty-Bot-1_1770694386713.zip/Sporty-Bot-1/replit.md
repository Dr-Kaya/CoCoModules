# Sporty Bot - ML Lifecycle Education App

## Overview

Sporty Bot is an interactive, gamified web application that teaches elementary students (grades 3-5) the machine learning lifecycle through a simulated binary classification experience. Students train a friendly robot character to distinguish between basketballs and soccer balls, experiencing the iterative nature of machine learning: collect data, train, test, improve, and deploy.

The application aligns with CSTA AI4K12 learning outcomes and features formative assessments, self-regulated learning checkpoints, and a certificate of completion.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: React useState/useCallback for local game state, TanStack React Query for server state
- **Animations**: Framer Motion for interactive animations and transitions
- **Styling**: Tailwind CSS with CSS variables for theming, supporting both light and dark modes
- **UI Components**: shadcn/ui component library (New York style) with Radix UI primitives

### Backend Architecture
- **Runtime**: Node.js with Express 5
- **Language**: TypeScript with ESM modules
- **Build Tool**: Custom build script using esbuild for server bundling, Vite for client
- **Development**: tsx for running TypeScript directly in development

### Data Storage
- **Current**: In-memory storage (MemStorage class) for certificates
- **Database Ready**: Drizzle ORM configured with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` using Zod for validation and type generation

### Application Flow
The game progresses through phases defined in the schema:
1. Welcome → Learn → Train (Phase 1) → Test (Phase 1) → Train (Phase 2) → Test (Phase 2) → Deploy → Assessment

Each phase includes:
- Interactive training with drag-and-drop ball classification
- Bot classification simulation with accuracy based on training examples
- Quick checks and self-regulated learning prompts
- Progress indicators and encouraging feedback

### Key Design Patterns
- **Shared Schema**: Zod schemas in `shared/schema.ts` define types used by both client and server
- **Component Composition**: Reusable components (Ball, Basket, SportyBot, QuickCheck) composed into screen components
- **Game State Machine**: Phase-based progression with state transitions managed in home page
- **Simulated ML**: Bot confidence improves with more training examples (65% with ≤8 examples, 90% with more)
- **Circular ML Lifecycle**: Visual representation of the iterative ML process (Collect → Train → Test → Improve → Deploy → repeat)
- **Diverse Training Data**: Ball images vary in rotation, scale, perspective, and brightness to demonstrate dataset diversity
- **Interactive Prediction**: "Show Me a Ball" activity lets users pick balls and ask Sporty Bot to predict

## External Dependencies

### UI/Animation
- Framer Motion for animations
- Radix UI primitives for accessible components
- Lucide React for icons
- class-variance-authority for component variants

### Data Layer
- Drizzle ORM with drizzle-zod for database schema and validation
- PostgreSQL driver (pg) - database URL expected in DATABASE_URL environment variable
- connect-pg-simple for session storage capability

### Development
- Vite with React plugin for frontend bundling
- Replit-specific plugins for development (runtime error overlay, cartographer, dev banner)
- esbuild for production server bundling

### Fonts
- Google Fonts: Nunito, Quicksand, Open Sans (loaded via client/index.html)
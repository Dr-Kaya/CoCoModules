import { randomUUID } from "crypto";
import type { Certificate, InsertCertificate } from "@shared/schema";

export interface IStorage {
  createCertificate(certificate: InsertCertificate): Promise<Certificate>;
  getCertificate(id: string): Promise<Certificate | undefined>;
}

export class MemStorage implements IStorage {
  private certificates: Map<string, Certificate & { id: string }>;

  constructor() {
    this.certificates = new Map();
  }

  async createCertificate(insertCertificate: InsertCertificate): Promise<Certificate & { id: string }> {
    const id = randomUUID();
    const certificate = { ...insertCertificate, id };
    this.certificates.set(id, certificate);
    return certificate;
  }

  async getCertificate(id: string): Promise<(Certificate & { id: string }) | undefined> {
    return this.certificates.get(id);
  }
}

export const storage = new MemStorage();

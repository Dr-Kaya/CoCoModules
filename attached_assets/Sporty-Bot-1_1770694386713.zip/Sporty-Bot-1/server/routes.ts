import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { certificateSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post("/api/certificates", async (req, res) => {
    try {
      const parsed = certificateSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid certificate data" });
      }
      const certificate = await storage.createCertificate(parsed.data);
      res.json(certificate);
    } catch (error) {
      res.status(500).json({ error: "Failed to create certificate" });
    }
  });

  app.get("/api/certificates/:id", async (req, res) => {
    try {
      const certificate = await storage.getCertificate(req.params.id);
      if (!certificate) {
        return res.status(404).json({ error: "Certificate not found" });
      }
      res.json(certificate);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch certificate" });
    }
  });

  return httpServer;
}
